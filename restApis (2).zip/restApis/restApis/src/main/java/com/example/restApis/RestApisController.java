package com.example.restApis;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;



@Controller
@ResponseBody
public class RestApisController {

    @Autowired
    RestApisService repos;

    @GetMapping("/")
    public String home(){
        return "welcome to home";
    }
    
    @PostMapping("/save")
    public String save(@RequestBody List<Students> std){
       
        return repos.saveService(std);
    }

    @GetMapping("fetch")
    public ResponseEntity<List<Students>> fetch(){
        return new ResponseEntity<>(repos.fetchService(),HttpStatus.OK);
    }

    @GetMapping("gender/{gender}")
    public ResponseEntity<List<Students>> group(@PathVariable String gender){
        return new ResponseEntity<>(repos.groupService(gender),HttpStatus.OK);
    }

    
}
