package com.example.restApis;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface  RestApisRepo extends  JpaRepository<Students, Long>{
   public  List<Students> findByGender(String name);
}
