package com.example.restApis;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RestApisService {

    @Autowired
    RestApisRepo repo;

     public  String saveService(List<Students> list){
          repo.saveAll(list);
          return "the data saved";
     }

     public List<Students> fetchService() {
         
          return repo.findAll();
     }
     public List<Students> groupService(String gender){
          return repo.findByGender(gender);
     } 
   
}
