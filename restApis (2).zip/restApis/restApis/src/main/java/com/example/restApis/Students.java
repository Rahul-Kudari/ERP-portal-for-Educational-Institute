package com.example.restApis;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Students {

    @Id
    long id;
    String name;
    String gender;
    long phone;
    String email;
    
}
