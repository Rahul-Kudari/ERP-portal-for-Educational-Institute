package com.example.restApis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApisApplicationTests {

	@Test
	void contextLoads() {
	}

}
